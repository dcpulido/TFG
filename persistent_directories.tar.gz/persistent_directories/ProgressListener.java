package ingenias.editor;

public interface ProgressListener {
	void setCurrentProgress(int progress); 
}
