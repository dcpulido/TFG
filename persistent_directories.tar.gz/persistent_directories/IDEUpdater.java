package ingenias.editor;

public interface IDEUpdater {
	public void updateIDEState(IDEState nids);
}
