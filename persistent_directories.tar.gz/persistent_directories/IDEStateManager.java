package ingenias.editor;

public class IDEStateManager {

}
