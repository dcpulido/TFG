package ingenias.editor.editiondialog;

public class ReferencePanel {

}
