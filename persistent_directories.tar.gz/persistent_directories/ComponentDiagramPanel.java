
/*
 Copyright (C) 2002 Jorge Gomez Sanz, Ruben Fuentes, Juan Pavon
 
 Modifications over original code from jgraph.sourceforge.net
 
 This file is part of INGENIAS IDE, a support tool for the INGENIAS
 methodology, availabe at http://grasia.fdi.ucm.es/ingenias or
 http://ingenias.sourceforge.net
 
 INGENIAS IDE is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.
 
 INGENIAS IDE is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with INGENIAS IDE; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 
 */
package ingenias.editor;

import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.Map;
import java.util.Hashtable;

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import java.awt.event.*;
import java.net.URL;
import java.util.Map;
import java.util.Hashtable;
import java.util.ArrayList;
import javax.swing.event.UndoableEditEvent;
import org.jgraph.JGraph;
import org.jgraph.graph.*;
import org.jgraph.event.*;
import java.util.Vector;
import org.jgraph.JGraph;
import org.jgraph.graph.*;
import org.jgraph.event.*;
import org.jgraph.plaf.basic.*;
import ingenias.editor.entities.*;
import ingenias.editor.cell.*;
import ingenias.editor.events.*;
import ingenias.exception.InvalidEntity;

public class ComponentDiagramPanel extends JGraph {
	
	public ComponentDiagramPanel(ComponentDiagramDataEntity mde, 
								 String nombre, Model m, 
								 BasicMarqueeHandler mh) {
		super(m, mh);
		
		this.getGraphLayoutCache().setFactory
		(new ingenias.editor.cellfactories.ComponentDiagramCellViewFactory());
	}
	
	
	//
	// Adding Tooltips
	//
	
	// Return Cell Label as a Tooltip
	public String getToolTipText(MouseEvent e) {
		if (e != null) {
			// Fetch Cell under Mousepointer
			Object c = getFirstCellForLocation(e.getX(), e.getY());
			if (c != null) {
				
				// Convert Cell to String and Return
				return convertValueToString(c);
			}
		}
		return null;
	}
	
	public static Vector<String> getAllowedEntities(){
		Vector<String> entities = new Vector<String>();
		
		entities.add("INGENIASComponent");
		
		entities.add("INGENIASCodeComponent");
		
		entities.add("Application");
		
		entities.add("EnvironmentApplication");
		
		entities.add("InternalApplication");
		
		entities.add("Task");
		
		entities.add("Test");
		
		entities.add("UMLComment");
		
		return entities;
	}
	
	public DefaultGraphCell createCell(String entity) throws InvalidEntity{
		
		/* 
		 // Trying to clean the code
		 public enum EntityValid 
		 {
			INGENIASCOMPONENT, 
			INGENIASCODECOMPONENT, 
			APPLICATION, 
			ENVIRONMENTAPPLICATION,
			INTERNALAPPLICATION, 
			TASK, 
			TEST, 
			UMLCOMMENT,
			NOVALUE;
		 }
		 
		 public static EntityValid toEntityValid(String str)
		 {
			try {
				return valueOf(str);
			} 
			catch (Exception ex) {
				return NOVALUE;
			}
		 }
		 
		 switch (EntityValid.valueOf(entity))
		 {
			case NOVALUE: 
				throw new ingenias.exception.InvalidEntity
						  ("Entity type "+entity+" is not allowed in this diagram");
			case default: 
				// new entity.Class entity.Object()
				// DefaultGraphCell vertex = new entity.Cell(entity.Object());
				// return vertex;
		 }
		 
		 */
		
		if (entity.equalsIgnoreCase("INGENIASComponent")) {
			INGENIASComponent nentity=new INGENIASComponent(((Model)getModel()).getNewId("INGENIASComponent"));
			DefaultGraphCell vertex = new INGENIASComponentCell(nentity);
			// Default Size for the cell with the new entity
			return vertex;
		}
		else
			
			if (entity.equalsIgnoreCase("INGENIASCodeComponent")) {
				INGENIASCodeComponent nentity=new INGENIASCodeComponent(((Model)getModel()).getNewId("INGENIASCodeComponent"));
				DefaultGraphCell vertex = new
				INGENIASCodeComponentCell(nentity);
				// Default Size for the cell with the new entity
				return vertex;
			}
			else
				
				if (entity.equalsIgnoreCase("Application")) {
					Application nentity=new Application(((Model)getModel()).getNewId("Application"));
					DefaultGraphCell vertex = new
					ApplicationCell(nentity);
					// Default Size for the cell with the new entity
					return vertex;
				}
				else
					
					if (entity.equalsIgnoreCase("EnvironmentApplication")) {
						EnvironmentApplication nentity=new EnvironmentApplication(((Model)getModel()).getNewId("EnvironmentApplication"));
						DefaultGraphCell vertex = new
						EnvironmentApplicationCell(nentity);
						// Default Size for the cell with the new entity
						return vertex;
					}
					else
						
						if (entity.equalsIgnoreCase("InternalApplication")) {
							InternalApplication nentity=new InternalApplication(((Model)getModel()).getNewId("InternalApplication"));
							DefaultGraphCell vertex = new
							InternalApplicationCell(nentity);
							// Default Size for the cell with the new entity
							return vertex;
						}
						else
							
							if (entity.equalsIgnoreCase("Task")) {
								Task nentity=new Task(((Model)getModel()).getNewId("Task"));
								DefaultGraphCell vertex = new
								TaskCell(nentity);
								// Default Size for the cell with the new entity
								return vertex;
							}
							else
								
								if (entity.equalsIgnoreCase("Test")) {
									Test nentity=new Test(((Model)getModel()).getNewId("Test"));
									DefaultGraphCell vertex = new
									TestCell(nentity);
									// Default Size for the cell with the new entity
									return vertex;
								}
								else
									
									if (entity.equalsIgnoreCase("UMLComment")) {
										UMLComment nentity=new UMLComment(((Model)getModel()).getNewId("UMLComment"));
										DefaultGraphCell vertex = new
										UMLCommentCell(nentity);
										// Default Size for the cell with the new entity
										return vertex;
									}
									else
										
										throw new ingenias.exception.InvalidEntity("Entity type "+entity+" is not allowed in this diagram"); 
	}
	
	public Dimension getDefaultSize(Entity entity) throws InvalidEntity{
		
		if (entity.getType().equalsIgnoreCase("INGENIASComponent")) {
			return INGENIASComponentView.getSize((INGENIASComponent)entity);      
		}
		else
			
			if (entity.getType().equalsIgnoreCase("INGENIASCodeComponent")) {
				return INGENIASCodeComponentView.getSize((INGENIASCodeComponent)entity);      
			}
			else
				
				if (entity.getType().equalsIgnoreCase("Application")) {
					return ApplicationView.getSize((Application)entity);      
				}
				else
					
					if (entity.getType().equalsIgnoreCase("EnvironmentApplication")) {
						return EnvironmentApplicationView.getSize((EnvironmentApplication)entity);      
					}
					else
						
						if (entity.getType().equalsIgnoreCase("InternalApplication")) {
							return InternalApplicationView.getSize((InternalApplication)entity);      
						}
						else
							
							if (entity.getType().equalsIgnoreCase("Task")) {
								return TaskView.getSize((Task)entity);      
							}
							else
								
								if (entity.getType().equalsIgnoreCase("Test")) {
									return TestView.getSize((Test)entity);      
								}
								else
									
									if (entity.getType().equalsIgnoreCase("UMLComment")) {
										return UMLCommentView.getSize((UMLComment)entity);      
									}
									else
										
										throw new ingenias.exception.InvalidEntity("Entity type "+entity+" is not allowed in this diagram"); 
	    
	}
	
	public DefaultGraphCell insert(Point point, String entity) throws InvalidEntity {
		// CellView information is not available after creating the cell.
		
		// Create a Map that holds the attributes for the Vertex
		Map map = new Hashtable();
		// Snap the Point to the Grid
		
		// Construct Vertex with no Label
		DefaultGraphCell vertex;
		Dimension size;
		
		vertex=this.createCell(entity);
		size=this.getDefaultSize((Entity)vertex.getUserObject());
		
		// Add a Bounds Attribute to the Map
		GraphConstants.setBounds(map, new Rectangle(point, size));
		
		// Construct a Map from cells to Maps (for insert)
		Hashtable attributes = new Hashtable();
		// Associate the Vertex with its Attributes
		attributes.put(vertex, map);
		// Insert the Vertex and its Attributes
		this.getModel().insert(new Object[] {vertex}, attributes, null, null, null);
		return vertex;
	}
	
	
	
	
	public DefaultGraphCell insertDuplicated(Point point, ingenias.editor.entities.Entity
											 entity) {
		// CellView information is not available after creating the cell.
		
		// Create a Map that holds the attributes for the Vertex
		Map map =new Hashtable();
		// Snap the Point to the Grid
		
		
		// Construct Vertex with no Label
		DefaultGraphCell vertex = null;
		Dimension size = null;
		
		
		if (entity.getClass().equals(INGENIASComponent.class)) {
			vertex = new INGENIASComponentCell( (INGENIASComponent) entity);
			// Default Size for the new Vertex with the new entity within
			size = INGENIASComponentView.getSize((INGENIASComponent) entity);
		}
		else
			
			if (entity.getClass().equals(INGENIASCodeComponent.class)) {
				vertex = new INGENIASCodeComponentCell( (INGENIASCodeComponent) entity);
				// Default Size for the new Vertex with the new entity within
				size = INGENIASCodeComponentView.getSize((INGENIASCodeComponent) entity);
			}
			else
				
				if (entity.getClass().equals(Application.class)) {
					vertex = new ApplicationCell( (Application) entity);
					// Default Size for the new Vertex with the new entity within
					size = ApplicationView.getSize((Application) entity);
				}
				else
					
					if (entity.getClass().equals(EnvironmentApplication.class)) {
						vertex = new EnvironmentApplicationCell( (EnvironmentApplication) entity);
						// Default Size for the new Vertex with the new entity within
						size = EnvironmentApplicationView.getSize((EnvironmentApplication) entity);
					}
					else
						
						if (entity.getClass().equals(InternalApplication.class)) {
							vertex = new InternalApplicationCell( (InternalApplication) entity);
							// Default Size for the new Vertex with the new entity within
							size = InternalApplicationView.getSize((InternalApplication) entity);
						}
						else
							
							if (entity.getClass().equals(Task.class)) {
								vertex = new TaskCell( (Task) entity);
								// Default Size for the new Vertex with the new entity within
								size = TaskView.getSize((Task) entity);
							}
							else
								
								if (entity.getClass().equals(Test.class)) {
									vertex = new TestCell( (Test) entity);
									// Default Size for the new Vertex with the new entity within
									size = TestView.getSize((Test) entity);
								}
								else
									
									if (entity.getClass().equals(UMLComment.class)) {
										vertex = new UMLCommentCell( (UMLComment) entity);
										// Default Size for the new Vertex with the new entity within
										size = UMLCommentView.getSize((UMLComment) entity);
									}
									else
										
									{}; // Just in case there is no allowed entity in the diagram
		
		if (vertex == null) {
			System.err.println(
							   "Object not allowed in ComponentDiagram diagram :"+ 
							   entity.getId()+":"+entity.getClass().getName()+
							   this.getClass().getName());    }
		else {
			
			// Add a Bounds Attribute to the Map
			GraphConstants.setBounds(map, new Rectangle(point, size));
			
			// Construct a Map from cells to Maps (for insert)
			Hashtable attributes = new Hashtable();
			// Associate the Vertex with its Attributes
			attributes.put(vertex, map);
			// Insert the Vertex and its Attributes
			this.getModel().insert(new Object[] {vertex}, attributes, null, null, null);
		}
		return vertex;
		
	}
	
	
}
